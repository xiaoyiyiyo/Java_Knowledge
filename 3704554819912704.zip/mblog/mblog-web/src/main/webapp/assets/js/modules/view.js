/*
+--------------------------------------------------------------------------
|   Mblog [#RELEASE_VERSION#]
|   ========================================
|   Copyright (c) 2014, 2015 mtons. All Rights Reserved
|   http://www.mtons.com
|
+---------------------------------------------------------------------------
*/

define(function(require, exports, module) {

    //require.async('ueditor.parse', function () {
    //    uParse('.post-content',{
    //        rootPath : window.UEDITOR_HOME_URL
    //    })
    //});

});