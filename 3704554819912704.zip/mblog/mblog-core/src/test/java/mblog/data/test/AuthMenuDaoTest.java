//package mblog.data.test;
//
//import java.util.List;
//
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import mblog.core.persist.dao.AuthMenuDao;
//import mblog.core.persist.entity.AuthMenuPO;
//
//public class AuthMenuDaoTest extends SpringTransactionalContextTests{
//
//	@Autowired
//	private AuthMenuDao authMenuDao;
//
//	@Test
//	public void testFindByParentId(){
//		List<AuthMenuPO> list = authMenuDao.findAll();
//		System.out.println(list);
//	}
//
//}
