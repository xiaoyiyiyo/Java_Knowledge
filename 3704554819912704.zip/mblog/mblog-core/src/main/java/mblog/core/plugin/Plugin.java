package mblog.core.plugin;

/**
 * 插件
 *
 * @author Beldon 2015/10/29
 */
public interface Plugin {
}
