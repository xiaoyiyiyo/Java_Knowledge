/*
+--------------------------------------------------------------------------
|   Mblog [#RELEASE_VERSION#]
|   ========================================
|   Copyright (c) 2014, 2015 mtons. All Rights Reserved
|   http://www.mtons.com
|
+---------------------------------------------------------------------------
*/
package mblog.core.data;

import mblog.core.persist.entity.AttachPO;

import java.io.Serializable;

/**
 * @author langhsu
 * 
 */
public class Attach extends AttachPO implements Serializable {
	private static final long serialVersionUID = -5858530547049180410L;
}
