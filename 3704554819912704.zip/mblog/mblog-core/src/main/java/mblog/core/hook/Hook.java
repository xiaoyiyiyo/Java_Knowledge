package mblog.core.hook;

/**
 * @author Beldon 2015/10/29
 */
public interface Hook{

//    boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler);
//
//    void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView)
//            throws Exception;
//
//    void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
//            throws Exception;
//
//    void afterConcurrentHandlingStarted( HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception;

}
