/*
+--------------------------------------------------------------------------
|   mtons [#RELEASE_VERSION#]
|   ========================================
|   Copyright (c) 2014, 2015 mtons. All Rights Reserved
|   http://www.mtons.com
|
+---------------------------------------------------------------------------
*/
package mblog.base.lang;

/**
 * @author langhsu
 *
 */
public interface EntityStatus {
	int ENABLED = 0; // 启动
	int DISABLED = 1; // 禁用
}
